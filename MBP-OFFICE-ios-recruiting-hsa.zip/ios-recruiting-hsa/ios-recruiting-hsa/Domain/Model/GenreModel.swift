//
//  GenreModel.swift
//  ios-recruiting-hsa
//
//  Created on 08-08-19.
//

struct GenreModel {
    let id: Int
    let name: String
}
