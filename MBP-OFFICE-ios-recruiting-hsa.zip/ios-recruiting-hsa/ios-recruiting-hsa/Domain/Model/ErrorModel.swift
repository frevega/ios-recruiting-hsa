//
//  ErrorModel.swift
//  ios-recruiting-hsa
//
//  Created on 07-08-19.
//

struct ErrorModel {
    let statusMessage: String
    let statusCode: Int
}
