//
//  ProductionCountryModel.swift
//  ios-recruiting-hsa
//
//  Created on 08-08-19.
//

struct ProductionCountryModel {
    let iso31661: String
    let name: String
}
