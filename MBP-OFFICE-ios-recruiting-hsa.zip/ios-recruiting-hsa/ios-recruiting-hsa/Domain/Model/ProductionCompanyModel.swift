//
//  ProductionCompanyModel.swift
//  ios-recruiting-hsa
//
//  Created on 08-08-19.
//

struct ProductionCompanyModel {
    let id: Int
    let logoPath: String?
    let name: String
    let originCountry: String
}
