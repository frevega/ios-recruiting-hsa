//
//  SpokenLanguageModel.swift
//  ios-recruiting-hsa
//
//  Created on 08-08-19.
//

struct SpokenLanguageModel {
    let iso6391: String
    let name: String
}
