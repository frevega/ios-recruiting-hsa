//
//  GridView.swift
//  ios-recruiting-hsa
//
//  Created on 10-08-19.
//

import Foundation

protocol GridView: BaseView {
    func showPopular(rows indexes: [IndexPath]?, shouldReloadTable: Bool)
}
