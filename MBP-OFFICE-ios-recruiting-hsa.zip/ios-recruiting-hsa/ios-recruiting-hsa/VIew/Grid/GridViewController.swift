//
//  GridViewController.swift
//  ios-recruiting-hsa
//
//  Created on 10-08-19.
//

import UIKit

class GridViewController: BaseViewController {
    @IBOutlet
    weak var collectionView: UICollectionView!
    private let presenter: GridPresenter
    private let delegate: GridViewDelegate
    private let datasource: GridViewDataSource
    private let prefetchDataSource: GridViewPrefetchDataSource
    var movies: [MovieView] {
        return presenter.getMovies()
    }
    var totalMovieCount: Int {
        return presenter.getTotalMovieCount()
    }
    
    private(set) var itemsPerRow: CGFloat = 2
    private(set) var sectionInsets = UIEdgeInsets(top: 50.0, left: 20.0, bottom: 50.0, right: 20.0)
    
    init(presenter: GridPresenter,
         delegate: GridViewDelegate,
         datasource: GridViewDataSource,
         prefetchDataSource: GridViewPrefetchDataSource
        ) {
        self.presenter = presenter
        self.delegate = delegate
        self.datasource = datasource
        self.prefetchDataSource = prefetchDataSource
        super.init(nibName: String(describing: GridViewController.self), bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = Constants.Labels.gridTitle
        delegate.attach(view: self)
        datasource.attach(view: self)
        prefetchDataSource.attach(view: self)
        presenter.attach(view: self)
        fetchPopularMovies()
    }
    
    @objc
    func fetchPopularMovies() {
        presenter.popularMovies()
    }
    
    override func prepare() {
        super.prepare()
        prepareCollectionView()
        prepareRefreshControl()
    }
    
    private func prepareCollectionView() {
        let cellName = String(describing: MovieCollectionViewCell.self)
        collectionView.register(UINib(nibName: cellName, bundle: nil), forCellWithReuseIdentifier: cellName)
        collectionView.delegate = delegate
        collectionView.dataSource = datasource
        collectionView.prefetchDataSource = prefetchDataSource
    }
    
    private func prepareRefreshControl() {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action:  #selector(fetchPopularMovies), for: .valueChanged)
        collectionView.refreshControl = refreshControl
    }
    
    func pushViewController(viewController: UIViewController) {
        navigationController?.pushViewController(viewController, animated: true)
    }
    
    func endOfCollectionReached() {
        fetchPopularMovies()
    }
}

extension GridViewController: GridView {
    func showPopular(rows indexes: [IndexPath]?, shouldReloadTable: Bool) {
        if (collectionView.refreshControl?.isRefreshing ?? false) {
            collectionView.refreshControl?.endRefreshing()
        }
        
        if shouldReloadTable {
            collectionView.reloadData()
        } else if let indexes = indexes {
            //collectionView.reloadItems(at: indexes)
            let indexPathsToReload = visibleIndexPathsToReload(intersecting: indexes)
            collectionView.reloadItems(at: indexPathsToReload)
        }
    }
}




extension GridViewController {
    func isLoadingCell(for indexPath: IndexPath) -> Bool {
        return indexPath.row >= movies.count
    }
    
    func visibleIndexPathsToReload(intersecting indexPaths: [IndexPath]) -> [IndexPath] {
        let indexPathsForVisibleRows = collectionView.indexPathsForVisibleItems
        let indexPathsIntersection = Set(indexPathsForVisibleRows).intersection(indexPaths)
        return Array(indexPathsIntersection)
    }
}
