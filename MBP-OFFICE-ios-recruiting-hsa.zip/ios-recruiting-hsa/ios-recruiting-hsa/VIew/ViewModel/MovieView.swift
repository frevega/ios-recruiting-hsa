//
//  MovieView.swift
//  ios-recruiting-hsa
//
//  Created on 10-08-19.
//

struct MovieView {
    let id: Int
    let title: String
    let posterPath: String?
}
