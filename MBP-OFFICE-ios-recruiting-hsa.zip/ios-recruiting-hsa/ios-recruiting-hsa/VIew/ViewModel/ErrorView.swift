//
//  ErrorView.swift
//  ios-recruiting-hsa
//
//  Created on 10-08-19.
//

struct ErrorView {
    let statusMessage: String
    let statusCode: Int
}
