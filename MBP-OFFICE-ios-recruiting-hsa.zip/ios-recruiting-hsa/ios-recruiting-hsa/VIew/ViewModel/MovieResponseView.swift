//
//  MovieResponseView.swift
//  ios-recruiting-hsa
//
//  Created on 14-08-19.
//

struct MovieResponseView {
    let page: Int
    let totalResults: Int
    let totalPages: Int
    let results: [MovieView]
}

