//
//  FavoriteDelegate.swift
//  ios-recruiting-hsa
//
//  Created on 8/12/19.
//

protocol FavoriteDelegate: class {
    func markFavorite()
}
