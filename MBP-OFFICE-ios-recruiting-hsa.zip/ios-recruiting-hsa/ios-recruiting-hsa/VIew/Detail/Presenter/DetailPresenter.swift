//
//  DetailPresenter.swift
//  ios-recruiting-hsa
//
//  Created on 11-08-19.
//

protocol DetailPresenter {
    func attach(view: DetailView)
    func movieDetail(id: Int)
    func addFavorite(movie: MovieDetailView)
    func isFavorite(movieId: Int)
}
