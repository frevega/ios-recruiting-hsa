//
//  FavoriteConstants.swift
//  ios-recruiting-hsa
//
//  Created on 8/12/19.
//

import UIKit

enum FavoriteConstants {
    enum Cells {
        enum Favorite {
            static let height: CGFloat = 215
        }
    }
}
