//
//  GenreEntity.swift
//  ios-recruiting-hsa
//
//  Created by on 07-08-19.
//

struct GenreEntity: Codable {
    let id: Int
    let name: String
}
